# Sandbox notes — TimeKeeper session

Written as a separate, standalone record of the environment the project was built in,
not part of the deliverable. Every number below was read out of the machine during the
session (mostly on 2026-09-15, `Asia/Calcutta` / UTC+05:30 local, `Asia/Calcutta` clock
zone reported); anything inferred is labelled as such.

## 1. What the box is

**Debian 13.6 "trixie", not bookworm.** Verbatim:

```
PRETTY_NAME="Debian GNU/Linux 13 (trixie)"
VERSION_ID="13"          VERSION="13 (trixie)"
VERSION_CODENAME=trixie  DEBIAN_VERSION_FULL=13.6
kernel 6.1.158+          x86_64   virt: kvm
```

- APT sources are `trixie` / `trixie-updates` / `trixie-security` (plus a nodesource repo).
- glibc 2.41, gcc 14.2 — both consistent with trixie; the earlier note in my head that
  "Debian 13" was close enough is now replaced by the file itself.
- The toolchain that mattered, `gcc-mingw-w64-i686` / `-x86_64` 14.2.0-17, binutils,
  cmake 3.31 and wine 10.0, were all pulled from trixie. `wine 10.0~repack-6` is a
  trixie-era package; bookworm shipped a much older Wine, so the distro was not cosmetic.
- KVM guest, not a container: no `/.dockerenv`, `systemd-detect-virt` answers `kvm`.
- Root user is `user`, with passwordless sudo. `/` is `rw,relatime,discard` — 25 GB,
  8.3 GB used, 16 GB free at the time of writing.

## 2. Who limited what

Two different authorities, and conflating them is what makes sandbox debugging confusing.

| Authority | What it actually controls | Did it ever stop the work? |
|---|---|---|
| The Linux box (KVM guest, Debian 13.6) | CPU, 25 GB disk, no `/dev` access to the host RTC, no CAP_SYS_TIME | Only in one place, below |
| The agent platform (Arena workspace snapshot) | What survives between turns: 128 MB / 10,000 files, with named exclusions | No — it never blocked a command; it decided what was *kept* |
| The bash tool wrapper | 30 s default timeout (max 1800 s), no controlling terminal, stdin closed, no state carried between calls | No, but it silently killed long-running jobs until they were moved to the process tool |

The one hard refusal found: setting the real-time clock. Everything else was a
*persistence* limit, not a permission limit — I could install packages with `sudo`, bind
sockets, create Wine prefixes and run PE binaries the whole time.

## 3. How the 128 MB was exceeded, and what the limit is

The warning read:

> This session created **2770.5 MB across 3,602 files**, past the 128.0 MB / 10,000-file
> limit. **3,524 files were not saved.**

What that tells you, and what it doesn't:

- It is a **retention cap on the persisted workspace snapshot**, not a disk quota. The
  container kept 25 GB and never said "no space".
- The byte count is **cumulative for the session**, so it survives deletion. Proof: at the
  time the banner appeared, the live tree was `827.0 KB / 78 files`. Today the whole of
  `/home/user` minus `~/.wine` is 2.7 MB.
- 3,524 of 3,602 files were "not saved" — those are precisely the transient artifacts:
  Wine prefixes, `build/` objects, cmake dirs under `/tmp`.

What actually produced 2.7 GB, in order of size:

1. **Wine prefixes.** Two of them (one per user, one root-owned for the privileged pass),
   because Wine refuses a prefix it does not own. Each `wineboot --init` writes a full
   `drive_c` skeleton. The one still on disk is 1.4 GB / 1,922 entries *after* pruning;
   a first-run prefix plus a root copy is where a few thousand files and ~1-2 GB come from.
2. **`apt-get` installs** (mingw-w64 ×2 arches, binutils, cmake, wine + wine32 i386
   multiarch). Multiarch alone drags hundreds of MB of 32-bit libraries.
3. **Build output**: `build/32`, `build/64`, `/tmp/cm-i386`, `/tmp/cm-x86_64` — small,
   but they are exactly what the exclusion list is designed to drop.
4. `/tmp` fixtures and stray test dirs (`/tmp/tkfix`, per-run `winetest-$$` dirs).

So the way out of the limit was not optimization; it was accepting that the limit only
governs what persists, and deleting the throwaway prefixes afterwards (`/tmp/tkfix` and
friends were removed once the work was verified). The deliverable never came close: the
tree is 2.1 MB with `build/` objects (1.4 MB of that) and 678 KB without.

## 4. When the sandbox knew

Not during the run. There is no in-band signal — no cgroup notification, no failed `write`,
nothing in `dmesg`. The count is taken at **turn boundaries**, when the platform snapshots
the workspace, and it is surfaced only as UI text in the user's panel. Which means:

- a command that writes 1 GB of junk returns `exit 0` and looks completely fine;
- you learn about the budget one turn late, from a screenshot;
- and the budget cannot be read programmatically from inside — there is no file, env var or
  syscall that reports it. `df` says 16 GB free, and that is *true*.

Practical consequence: treat anything regenerable as free to create, but delete it before
the end of the turn if it is not going to be excluded by name (`build`, `dist`, `.venv`,
`node_modules`, … are excluded; `~/.wine` and `bin/` are **not**, which is why 1.4 GB of
Wine counted and the object files didn't).

## 5. Limitations found, with the evidence

| # | Limitation | Evidence | Cost it imposed |
|---|---|---|---|
| 1 | **Everything outside `/home/user` is ephemeral.** Installed packages, `/usr/bin`, processes, `/tmp` | `i686-w64-mingw32-gcc`, `wine`, `cmake` all reported MISSING mid-project although they had been installed earlier and are in no excluded path | Full reinstall before a one-line fix could be built |
| 2 | **The image itself gets rebuilt.** `/var/log/apt/history.log` shows the base installs dated 2026-07-14 and 2026-07-23, and my *only* two entries dated 2026-09-15 06:51 (mingw+cmake) and 07:02 (wine) | apt history survives; a session from earlier the same day had installed the same packages | This is the mechanism behind #1 — a fresh base image, not a deleted `/usr` |
| 3 | **File mtimes are rewritten by the restore.** 14 of 16 acceptance logs, written hours apart, all read `06:50` | `find -printf '%TY-%Tm-%Td %TH:%TM'` | Timeline reconstruction from mtimes is impossible; I had to use text inside the logs, or apt's log |
| 4 | **Privilege gaps:** no `CAP_SYS_TIME`, so `SetSystemTime` fails | Wine reported `FAILED Win32 1314` for a non-root token; the root pass (`sudo` + its own prefix) accepted the write | The "clock really moved" acceptance tests need the privileged pass, doubling run time |
| 5 | **UDP/123 is blocked outbound** | `sntp_responder.py` on `:123` needed the fixture on a high port (12300); a live check to `0.pool.ntp.org:123` timed out | The clock had to be corrected from an HTTP `Date` header instead (tiers 1 and 2 of the product under test) |
| 6 | **The clock drifts and self-corrects** | After the final run: `local-ntp drift=-44 s` against *two* independent HTTP sources (google, cloudflare agreed to the second) | Fixed with `sudo date -u -s @<epoch>`; recheck 0 s. Must be re-verified after any run that touches time |
| 7 | **`/tmp` is a 993 MB tmpfs** shared with `/dev/shm` | `df`: `tmpfs 993M` | A Wine prefix placed there filled it to 100 % and left root-owned files behind |
| 8 | **A clock jump makes `make` silently no-op** | `make: Warning: Clock skew detected` after a test set the date backwards | `make clean` + `find … -exec touch {} +` before every trust-worthy rebuild |
| 9 | **A reset clears file modes** | The harness's own `sudo tests/acceptance.sh --priv` re-invocation died with `rc=126 Permission denied`; the file was `-rw-r--r--` | One `FAIL` in `accK.log` that was pure environment, not code. Needed `chmod +x` |
| 10 | **`command -v` is not a survey** | `windres` "MISSING" — the binary is `i686-w64-mingw32-windres` | Nearly concluded the resource toolchain was absent |
| 11 | **Long jobs die at the bash timeout** | Default 30 s; `wineboot --init` takes ~53 s, a full acceptance run ~46-153 s | Anything that must outlive a call goes to the process tool |
| 12 | **File previews are a network-less sandboxed iframe** | Documented platform behaviour; affects deliverable rendering, not builds | Inline styles/SVG/data URIs only |
| 13 | **The file viewer and the snapshot disagree about what exists** | UI: `78/10K files`, while `find /home/user/timekeeper | wc -l` = 106 | The difference is the exclusion policy, not lost work — `build/` is excluded by name |

Nothing in this list was knowable up front from inside the box. #1/#2/#9 in particular are
only visible *after* they have cost you something, which is why the harness now documents
its own costs and mode requirements in its header comment.

## 6. How the limits shaped the engineering (the useful part)

- **Verify by cheap invariants, not by review.** The `msvcrt.dll` regression — one bare
  `memmove` added after a global rename — was invisible in review and costs 0.03 s in
  `tests/pe_audit.py`. That check is now part of `make check`.
- **Never let the only oracle be slow.** A log-rotation bug whose only test was a 46-second
  Wine run consumed a whole turn. Extracting the decision into a pure function
  (`tk_log_trim_tail`) turned it into a 0.14 s unit test — and revealed the *code* had been
  wrong (a non-idempotent forward scan) *and* the test had been wrong (marker parked at the
  edge of the keep window). Three different Python simulations of the logic, done before
  that, produced three wrong conclusions; only running the real function counted.
- **Test code is product code here.** `src/selftest.c` is linked into the shipped .exe, so
  the suite must be written size-aware: a fill macro expanded at four sites cost ~5 KB, and
  the rotation group measured 2,560 B. Both are now host-only, with the reason in a comment.
- **Two build systems, one truth.** CMake and `Makefile.mingw` are verified to produce
  byte-identical artifacts (77,312 / 71,680 B). CMake once silently omitted `src/crt_start.c`
  and produced a plausible-looking 32 KB stub; an entry-point assertion in `CMakeLists.txt`
  now prevents that class of error.

## 7. Measured cost of the checks (this box, this toolchain)

| Operation | Time |
|---|---|
| `make -f Makefile.mingw test` (host suite, 8,852 checks + ASan/UBSan build) | 0.14 s |
| `python3 tests/pe_audit.py` (both binaries, subsystem/imports/manifest/size) | 0.03 s |
| `make -f Makefile.mingw all` (both arches from scratch, 6.7 s) | 6.7 s |
| one `wine TimeKeeper.exe /dry-run` (including Wine startup) | 0.38 s |
| `wineboot --init` (fresh prefix) | 53 s |
| `tests/acceptance.sh` — user pass | ~46 s |
| `tests/acceptance.sh` — with privileged pass | ~153 s |
| `apt-get install` mingw ×2 + binutils + cmake | 15 s |
| `apt-get install` wine + wine32:i386 + wine64 | 50 s |

Read as a workflow: iterate against the first two rows (together about a fifth of a
second), rebuild in under 7, and reserve Wine runs for behaviour only a real PE can show —
argv parsing, token privileges, file sharing, the log pipeline.

## 8. Run count for the session

Counting the *acceptance matrix* runs, which are the ones with retained evidence
(`/home/user/acc*.log`, named `acc`, then hex-style `acc2…acc9`, `accA…accL`):

- **16 runs have a log on disk today.**
- **5 more are known to have happened** — the sequence has gaps at 7, B, C, D, E, so their
  logs are gone (deleted or overwritten). **That makes 21 acceptance runs** in the session.
  (The count is inferred from the gap pattern in the naming, not from a log.)
- Results, read straight from each file:

| log | passed / failed / skipped | what that run was for |
|---|---|---|
| `acc` | 29 / 7 / 1 | first full matrix; harness + app both immature |
| `acc2` | 29 / 7 / 1 | re-run to separate flaky from real failures |
| `acc3` | 32 / 4 / 1 | after fixing argv parsing and the SNTP reply guard |
| `acc4` | — (aborted) | harness bug: `line 377: RESP4: unbound variable` under `set -u`; its tail is the live-network proof that an 804 ms delta is correctly *not* written |
| `acc5` | 38 / 4 / 1 | HTTP tier: `HTTP_QUERY_RAW_HEADERS_CRLF` switch |
| `acc6` | 38 / 4 / 1 | log-path writability probing |
| `acc8` | 38 / 4 / 1 | size-reduction pass begins |
| `acc9` | 41 / 5 / 1 | `-nostartfiles` + `tklibc` rework; 5 new failures from the CRT removal |
| `accA` | 41 / 5 / 1 | re-run to confirm those 5 were real, not environment |
| `accF` | 43 / 5 / 1 | idempotence + self-update rules pinned |
| `accG` | 43 / 5 / 1 | date-granular skip rule (test 5) |
| `accH` | 43 / 5 / 1 | privilege-denial exit codes and messages |
| `accI` | 48 / 0 / 1 | first fully green matrix |
| `accJ` | 47 / 2 / 1 | regression: stray `memmove` → `msvcrt` + the rotation tail loss |
| `accK` | 48 / 1 / 1 | after `tk_memmove` fix; the 1 failure was `chmod +x` (rc=126), not code |
| `accL` | 49 / 0 / 1 | final, after the trim rewrite and fixture correction |

- Per-run duration was not written into the logs. The two runs I started in the last turn
  are measured from the harness itself: `accK` **46 s** (user pass only), `accL`
  **~153 s** (user + privileged). The remaining 19 are unmeasured individually; they are
  the same script, so 45-150 s each is a fair range, i.e. **roughly 25 minutes of run time
  in acceptance tests across the session**, which is the single largest identifiable
  expense. Everything else measured, summed from the visible call records of the last two
  turns, is ~26 s of build/test/audit work.
- The 1 skipped check in every run is the same one: Wine cannot drop a token to a genuine
  limited user, so the real non-admin case is covered by the manual Win7 checklist
  (`tests/win7-vm-tests.md` §6) instead of pretending to be automated.

## 9. If you rebuild this environment

1. `sudo apt-get update && sudo apt-get install -y --no-install-recommends gcc-mingw-w64-i686 gcc-mingw-w64-x86-64 binutils-mingw-w64-i686 binutils-mingw-w64-x86-64 cmake` (15 s), then for running PEs: `sudo dpkg --add-architecture i386 && sudo apt-get update && sudo apt-get install -y --no-install-recommends wine wine32:i386 wine64` (50 s).
2. `export WINEPREFIX=$HOME/.wine WINEDEBUG=-all && wineboot --init` (53 s). Keep it under `$HOME`, never `/tmp`; a second prefix owned by root for the privileged pass.
3. `chmod +x tests/acceptance.sh`.
4. Check the clock against an HTTP `Date` before and after; `-44 s` drift is enough to break TLS-dependent tooling and enough to make `make` lie.
5. Expect nothing in `/usr` or `/tmp` to survive a gap in the conversation; expect `bin/*.exe` and `src/` to survive fine.
